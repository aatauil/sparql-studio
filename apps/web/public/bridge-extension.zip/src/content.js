window.postMessage(
  { type: "SPARQL_STUDIO_BRIDGE_ANNOUNCE", extensionId: chrome.runtime.id },
  "*"
);
